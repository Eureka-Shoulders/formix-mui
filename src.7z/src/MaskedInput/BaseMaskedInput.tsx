import { TextField, TextFieldProps } from '@mui/material';
import InputMask, { Props as InputMaskProps } from 'react-input-mask';

export type BaseMaskedInputProps = {
  label?: string;
  textFieldProps?: TextFieldProps;
} & InputMaskProps;

const BaseMaskedInput = ({
  label,
  mask,
  textFieldProps,
  ...props
}: BaseMaskedInputProps) => {
  return (
    <InputMask mask={mask} {...props}>
      {() => <TextField {...textFieldProps} label={label} fullWidth />}
    </InputMask>
  );
};

export default BaseMaskedInput;
