import { TextField, TextFieldProps } from '@mui/material';
import { observer } from 'mobx-react-lite';
import InputMask, { Props as InputMaskProps } from 'react-input-mask';

import { useField } from '@euk-labs/formix/hooks';

export type FXMaskedInputProps = {
  name: string;
  label?: string;
  textFieldProps?: TextFieldProps;
} & InputMaskProps;

const FXMaskedInput = ({
  name,
  label,
  mask,
  textFieldProps,
  ...props
}: FXMaskedInputProps) => {
  const { field, meta, helpers } = useField(name);

  const setValueOnField = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (!!value) {
      helpers.setValue(value);
    }
  };

  return (
    <InputMask
      mask={mask}
      {...props}
      {...field}
      value={field.value as string}
      onChange={setValueOnField}
    >
      {() => (
        <TextField
          {...textFieldProps}
          label={label}
          fullWidth
          error={meta.touched && !!meta.error}
          helperText={meta.touched && meta.error}
        />
      )}
    </InputMask>
  );
};

export default observer(FXMaskedInput);
